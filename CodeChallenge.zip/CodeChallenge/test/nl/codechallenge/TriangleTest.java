package nl.codechallenge;

import static org.junit.Assert.*;

import org.junit.Test;

public class TriangleTest {

	public static final String ERROR_MESSAGE_NEGATIVE_VALUE = "Base and height of triangle should be positive values";

	@Test
	public void testBaseAndHightZero() {
		Triangle triangle = new Triangle(0, 0);
		double result = triangle.calculateArea();
		assertEquals(0, result, 0);
	}

	@Test
	public void testAreaOfTriangleWhenBaseZeroAndHightPositive() {
		Triangle triangle = new Triangle(0, 5);
		double result = triangle.calculateArea();
		assertEquals(0, result, 0);
	}

	@Test
	public void testAreaOfTriangleWhenBasePositiveAndHightZero() {
		Triangle triangle = new Triangle(5, 0);
		double result = triangle.calculateArea();
		assertEquals(0, result, 0);
	}
	
		@Test
		public void testAreaOfTriangleWhenBaseHasNegativeValue() {
			try {
				new Triangle(-1, 5).calculateArea();
			} catch (RuntimeException e) {
				assertEquals(ERROR_MESSAGE_NEGATIVE_VALUE, e.getMessage());
			}

		
	}

	@Test
	public void testAreaOfTriangleWhenHeightHasNegativeValue() {
		try {
			new Triangle(1, -5).calculateArea();
		} catch (RuntimeException e) {
			assertEquals(ERROR_MESSAGE_NEGATIVE_VALUE, e.getMessage());
		}

	}

	@Test
	public void testAreaOfTriangleWithNegativeValues() {
		try {
			new Triangle(-1, -5).calculateArea();
		} catch (RuntimeException e) {
			assertEquals(ERROR_MESSAGE_NEGATIVE_VALUE, e.getMessage());
		}
	}

	
		@Test
	public void testAreaOfTriangleWithHight1() {
		Triangle triangle = new Triangle(5, 1);
		double result = triangle.calculateArea();
		assertEquals(2.5, result, 0);
	}

	@Test
	public void testAreaOfTriangleWithBase1() {
		Triangle triangle = new Triangle(1, 10);
		double result = triangle.calculateArea();
		assertEquals(5, result, 0);
	}

	@Test
	public void testAreaOfTriangleBaseAndHightGreaterThan1AndLessThanMaxDouble() {
		Triangle triangle = new Triangle(1000, 500);
		double result = triangle.calculateArea();
		assertEquals(250000.0, result, 0);
	}

	@Test
	public void testAreaOfTrianglWithBaseAsMaximumValue() {
		Triangle triangle = new Triangle(Double.MAX_VALUE, 5);
		double result = triangle.calculateArea();
		assertEquals(Double.POSITIVE_INFINITY, result, 0);
	}

	@Test
	public void testAreaOfTrianglWithHeightAsMaximumValue() {
		Triangle triangle = new Triangle(5, Double.MAX_VALUE);
		double result = triangle.calculateArea();
		assertEquals(Double.POSITIVE_INFINITY, result, 0);
	}

	@Test
	public void testAreaOfTrianglWithHeightAndBaseAsMaximumValue() {
		Triangle triangle = new Triangle(Double.MAX_VALUE, Double.MAX_VALUE);
		double result = triangle.calculateArea();
		assertEquals(Double.POSITIVE_INFINITY, result, 0);
	}

	@Test
	public void testAreaOfTrianglWithHeightAndBaseAsGreaterThanMaximumValue() {
		Triangle triangle = new Triangle(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
		double result = triangle.calculateArea();
		assertEquals(Double.POSITIVE_INFINITY, result, 0);
	}

	@Test
	public void testAreaOfTrianglWithNull() {
		Triangle triangle = new Triangle(Double.NaN, Double.NaN);
		double result = triangle.calculateArea();
		assertEquals(Double.NaN, result, 0);
	}

	@Test
	public void testAreaOfTrianglWithBaseAsNull() {
		Triangle triangle = new Triangle(Double.NaN, 2);
		double result = triangle.calculateArea();
		assertEquals(Double.NaN, result, 0);
	}

	@Test
	public void testAreaOfTrianglWithBaseDecimal() {
		Triangle triangle = new Triangle(10.5, 10);
		double result = triangle.calculateArea();
		assertEquals(52.5, result, 0);
	}

	@Test
	public void testAreaOfTrianglWithHightDecimal() {
		Triangle triangle = new Triangle(10, 10.5);
		double result = triangle.calculateArea();
		assertEquals(52.5, result, 0);
	}
}
