package nl.codechallenge;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;

public class SubsetTest {

	@Test
	 public  void testTwoListsWhichareNotSubset() {
        Subset subset = new Subset();
        List<Object> list1 = Arrays.asList(new Integer[] { 1, 2, 8, 4, 5, 6, 4 });
        List<Object> list2 = Arrays.asList(new Integer[] { 1, 3, 3, 2, 5, 8 });
        String result = subset.checkSubsetAndReturnDifference(list1,list2);
        String expected = "List 1 compare List 2: [4, 6, 4] is not present in List 2." + "\n" + "List 2 compare List 1: [3, 3] is not present in List 1.";
        
        assertEquals(expected, result);
    }
	
	@Test
	 public  void testList1IsSubsetOfList2() {
       Subset subset = new Subset();
       List<Object> list1 = Arrays.asList(new Integer[] { 1, 3, 3, 7, 9, 0, 9, 1 });
       List<Object> list2 = Arrays.asList(new Integer[] { 3, 7, 3, 1, 1, 0, 9, 9, 8 });
       String result = subset.checkSubsetAndReturnDifference(list1,list2);
       String expected = "List 1 compare List 2: pass." + "\n" + "List 2 compare List 1: [8] is not present in List 1.";
       assertEquals(expected, result);
   }
	
	@Test
	 public  void testList1IsSubsetOfList2InString() {
      Subset subset = new Subset();
      List<Object> list1 = Arrays.asList(new String[] { "O", "S" });
      List<Object> list2 = Arrays.asList(new String[] { "O", "S", "D" });
      String result = subset.checkSubsetAndReturnDifference(list1,list2);
      String expected = "List 1 compare List 2: pass." + "\n" + "List 2 compare List 1: [D] is not present in List 1.";
      assertEquals(expected, result);
  }
	
	@Test
	 public  void testList1AsStringIsNotSubsetOfList2AsInt() {
     Subset subset = new Subset();
     List<Object> list1 = Arrays.asList(new String[] { "O", "S" });
     List<Object> list2 = Arrays.asList(new Integer[] { 3, 7, 3, 1, 1, 0, 9, 9, 8 });
     String result = subset.checkSubsetAndReturnDifference(list1,list2);
     String expected = "List 1 compare List 2: [O, S] is not present in List 2." + "\n" + "List 2 compare List 1: [3, 7, 3, 1, 1, 0, 9, 9, 8] is not present in List 1.";
     assertEquals(expected, result);
 }
	
	@Test
	 public  void testList1AsIntIsNotSubsetOfList2AsString() {
    Subset subset = new Subset();
    List<Object> list2 = Arrays.asList(new String[] { "O", "S" });
    List<Object> list1 = Arrays.asList(new Integer[] { 3, 7, 3, 1, 1, 0, 9, 9, 8 });
    String result = subset.checkSubsetAndReturnDifference(list1,list2);
    String expected = "List 1 compare List 2: [3, 7, 3, 1, 1, 0, 9, 9, 8] is not present in List 2." + "\n" + "List 2 compare List 1: [O, S] is not present in List 1.";
    assertEquals(expected, result);
}
	
	 @Test
	    public  void testList1AsIntIsNotSubsetOfList2AsNull() {
	        Subset subset = new Subset();
	        List<Object> list1 = Arrays.asList(new Integer[] { 1, 2, 8, 4, 5, 6, 4 });
	        String result = subset.checkSubsetAndReturnDifference(list1,null);
	        String expected = "List 1 compare List 2: [1, 2, 8, 4, 5, 6, 4] is not present in List 2." + "\n" + "List 2 compare List 1: null is not present in List 1.";
	        assertEquals(expected, result);
	    }
	
	 @Test
	    public  void testList1AsNullIsNotSubsetOfList2AsInt() {
	        Subset subset = new Subset();
	        List<Object> list2 = Arrays.asList(new Integer[] { 1, 2, 8, 4, 5, 6, 4 });
	        String result = subset.checkSubsetAndReturnDifference(null,list2);
	        String expected = "List 1 compare List 2: null is not present in List 2." + "\n" + "List 2 compare List 1: [1, 2, 8, 4, 5, 6, 4] is not present in List 1.";
	        assertEquals(expected, result);
	    }
	
		
	  @Test
	    public  void testLis1AsEmptyIsNotSubsetOfList2AsInt() {
	        Subset subset = new Subset();
	        List<Object> list2 = Arrays.asList(new Integer[] { 1, 2, 8, 4, 5, 6, 4 });
	        String result = subset.checkSubsetAndReturnDifference(new ArrayList<>(),list2);
	        String expected = "List 1 compare List 2: [] is not present in List 2." + "\n" + "List 2 compare List 1: [1, 2, 8, 4, 5, 6, 4] is not present in List 1.";
	        assertEquals(expected, result);
	    }
	 
	  
	  @Test
	    public  void testLis1AsIntIsNotSubsetOfList2AsEmpty() {
	        Subset subset = new Subset();
	        List<Object> list1 = Arrays.asList(new Integer[] { 1, 2, 8, 4, 5, 6, 4 });
	        String result = subset.checkSubsetAndReturnDifference(list1,new ArrayList<>());
	        String expected = "List 1 compare List 2: [1, 2, 8, 4, 5, 6, 4] is not present in List 2." + "\n" + "List 2 compare List 1: [] is not present in List 1.";
	        assertEquals(expected, result);
	    }
	  
}
