package nl.codechallenge;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;

public class PrintNumbersTest {

	@Test
	public void testPrintNumbers() {
		PrintNumbers numbers = new PrintNumbers();

		Assert.assertEquals("1,2,3,4,5,6,7,8,9,10", numbers.printNumbers());
	}

}
