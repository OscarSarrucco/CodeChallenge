package nl.codechallenge;

public class Triangle {

	 private final double base;

	    private final double height;

	    public Triangle(final double base, final double height) {
	        this.base = base;
	        this.height = height;
	    }

	   /*

	             */
	    public double calculateArea() {
	        if (base < 0 || height < 0) {
	            throw new RuntimeException("Base and height of triangle should be positive values");
	        }
	        return (base * height) / 2;
	    }
	
	
}
