package nl.codechallenge;

import java.util.ArrayList;
import java.util.List;

public class Subset {

	public String checkSubsetAndReturnDifference(final List<Object> list1, final List<Object> list2) {

        return list1ComparesList2(list1, list2) + "\n" + list2ComparesList1(list1, list2) ;
    }

    private String list2ComparesList1(List<Object> list1, List<Object> list2) {
        String output = "";
       
  
        if(list2 == null || list2.isEmpty() || list1 == null || list1.isEmpty()) {
            return "List 2 compare List 1: " + list2 + " is not present in List 1.";
        }
        List<Object> result = new ArrayList<>(list2);
        result.removeAll(list1);
        if (result.isEmpty()) {
            output = "List 2 compare List 1: pass.";
        } else {
            output = "List 2 compare List 1: " + result + " is not present in List 1.";
        }
        
        return output;
    }

    private String list1ComparesList2(List<Object> list1, List<Object> list2) {
        String output = "";
     
     
        
        if(list2 == null || list2.isEmpty() || list1 == null || list1.isEmpty()) {
            return "List 1 compare List 2: " + list1 + " is not present in List 2.";
        }
        List<Object> result = new ArrayList<>(list1);
        result.removeAll(list2);
        if (result.isEmpty()) {
            output = "List 1 compare List 2: pass.";
        } else {
            output = "List 1 compare List 2: " + result + " is not present in List 2.";
        }
        return output;
    }
}
